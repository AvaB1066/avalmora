
# Ollivander's Lamp
Files for the lamp published on [url to come]

Detailed instructions on [url to come]

Fan made and supported - not affiliated with Universal Studios.  
